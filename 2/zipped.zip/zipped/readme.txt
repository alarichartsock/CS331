To run on the flip servers:

python3 GameDriver.py [player1] [player2]
